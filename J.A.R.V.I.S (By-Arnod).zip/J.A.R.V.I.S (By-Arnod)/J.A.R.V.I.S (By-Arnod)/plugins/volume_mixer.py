import ctypes

def run(command_arguments="", **kwargs):
    action = str(command_arguments).strip().lower()
    
    # Access native Windows audio driver layout interfaces (WM_APPCOMMAND)
    WM_APPCOMMAND = 0x0319
    HWND_BROADCAST = 0xffff
    
    # Shell execution command parameters
    APPCOMMAND_VOLUME_MUTE = 0x80000
    APPCOMMAND_VOLUME_DOWN = 0x90000
    APPCOMMAND_VOLUME_UP = 0xa0000

    if "mute" in action:
        ctypes.windll.user32.SendMessageW(HWND_BROADCAST, WM_APPCOMMAND, 0, APPCOMMAND_VOLUME_MUTE)
        return "System audio muted successfully, sir."
    elif "up" in action or "increase" in action:
        # Loops twice to bump sound up noticeably
        for _ in range(2): ctypes.windll.user32.SendMessageW(HWND_BROADCAST, WM_APPCOMMAND, 0, APPCOMMAND_VOLUME_UP)
        return "Master system audio levels stepped upward."
    elif "down" in action or "decrease" in action:
        for _ in range(2): ctypes.windll.user32.SendMessageW(HWND_BROADCAST, WM_APPCOMMAND, 0, APPCOMMAND_VOLUME_DOWN)
        return "Master system audio levels stepped downward."
        
    return "Audio layout directive option not recognized. Please specify up, down, or mute."

PLUGIN = {
    "name": "volume_mixer",
    "description": "Modifies master Windows hardware system audio volume levels or toggles muting states."
}
