import urllib.request
import re
import json

def run(command_arguments="", **kwargs):
    """
    Dynamically routes to specific country feeds based on your vocal input.
    Supports names like India, USA, UK, Canada, Australia, etc.
    """
    country_input = str(command_arguments).strip().lower()
    
    # 1. Catch initial empty launch sequence to prompt the user for input
    if not country_input:
        return "Sir, please select a country to fetch local news from. You can specify India, USA, UK, Canada, or Australia."

    # 2. Master Map Layout for Regional Feed Matrices
    feed_matrix = {
        "india": "https://indiatimes.com",
        "usa": "http://bbci.co.uk",
        "uk": "http://bbci.co.uk",
        "canada": "http://bbci.co.uk",
        "australia": "http://bbci.co.uk"
    }

    # Match input or default to global news if missing
    target_url = feed_matrix.get(country_input, "http://bbci.co.uk")
    display_country = country_input.upper() if country_input in feed_matrix else "GLOBAL WIRE"

    try:
        req = urllib.request.Request(target_url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=8) as response:
            xml_content = response.read().decode('utf-8', errors='ignore')
            
            # Extract raw title text layers inside item blocks
            titles = re.findall(r'<title><!\[CDATA\[(.*?)\]\]></title>', xml_content)
            if not titles:
                titles = re.findall(r'<title>(.*?)</title>', xml_content)
            
            # Filter structural tags out to leave pure headline strings
            clean_headlines = []
            for t in titles:
                clean = re.sub(r'<[^>]*>', '', t).replace('&quot;', '"').replace('&amp;', '&').strip()
                if len(clean) > 15 and "rss" not in clean.lower() and "bbc" not in clean.lower():
                    clean_headlines.append(clean)
            
            # Slice the top 3 items to present cleanly
            final_stories = clean_headlines[:3]
            
            if final_stories:
                briefing = f"Synchronizing wireless feeds for {display_country}. Here are the top headlines, sir: "
                for index, story in enumerate(final_stories, 1):
                    briefing += f"Headline {index}: {story}. "
                return briefing
                
            return f"Feed data for {display_country} downloaded successfully, sir, but no text parameters could be parsed."

    except Exception as e:
        return f"Unable to safely hook into the {display_country} broadcast pipeline network layer right now, sir."

# Register the plugin configurations cleanly with the core engine validator
PLUGIN = {
    "name": "live_news",
    "description": "Bypasses default broken scrapers to pull and read live news briefs sorted by selected countries."
}
