import subprocess
import re

def run(command_arguments="", **kwargs):
    try:
        # Run a native network trace ping command to Google servers
        result = subprocess.run(["ping", "8.8.8.8", "-n", "3"], capture_output=True, text=True)
        if result.returncode == 0:
            # Slices out the average response latency times
            times = re.findall(r"Average = (\d+)ms", result.stdout)
            ping_speed = times[0] if times else "unknown"
            return f"Network link is active, sir. Your latency speed to primary servers is holding steady at {ping_speed} milliseconds."
        return "Ping sequence failed. Network interface card reports no active internet connection pathway."
    except Exception as e:
        return f"Diagnostics interrupted: {str(e)}"

PLUGIN = {
    "name": "speed_test",
    "description": "Runs a localized network connection speed test using system terminal utilities."
}
