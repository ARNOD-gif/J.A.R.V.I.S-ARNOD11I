import os
import datetime
from PIL import ImageGrab # Runs automatically via requirements.txt

def run(command_arguments="", **kwargs):
    # Set target storage directory path
    target_dir = "C:\\Users\\ACER\\Videos\\Captures"
    if not os.path.exists(target_dir):
        os.makedirs(target_dir)
        
    # Create a clean, unique file name using the exact timestamp
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    file_name = f"Screenshot_{timestamp}.png"
    full_path = os.path.join(target_dir, file_name)
    
    try:
        # Capture full bounding monitor grid
        screenshot = ImageGrab.grab()
        screenshot.save(full_path, "PNG")
        return f"Desktop captured successfully, sir. File saved as '{file_name}' inside your Captures folder."
    except Exception as err:
        return f"Failed to capture system interface display: {str(err)}"

PLUGIN = {
    "name": "screenshot_tool",
    "description": "Takes a full desktop screenshot and saves it as a PNG file inside the Captures folder."
}
