import os

def run(command_arguments="", **kwargs):
    target = str(command_arguments).strip().lower()
    apps = {
        "chrome": "start chrome",
        "notepad": "notepad.exe",
        "calculator": "calc.exe",
        "cmd": "start cmd"
    }
    if target in apps:
        os.system(apps[target])
        return f"Launching {target} immediately, sir."
    return f"Application '{target}' is not mapped in my system registry."

PLUGIN = {"name": "app_launcher", "description": "Launches desktop software programs via console executions."}
