import os
import sys
import json
import ctypes
import random
import datetime
import webbrowser
import math
import hashlib

def run(command_arguments="", **kwargs):
    phrase = str(command_arguments).strip().lower()
    
    # -------------------------------------------------------------------------
    # 1. SCREEN MAGNIFIER ("open magnifier")
    # -------------------------------------------------------------------------
    if "open magnifier" in phrase or "magnify screen" in phrase:
        os.system("magnify")
        return "Launching native Windows Screen Magnifier utility, sir."

    # -------------------------------------------------------------------------
    # 2. VIRTUAL KEYBOARD TOGGLE ("open keyboard")
    # -------------------------------------------------------------------------
    elif "open keyboard" in phrase or "virtual keyboard" in phrase:
        os.system("osk")
        return "Displaying the on-screen virtual keyboard portal."

    # -------------------------------------------------------------------------
    # 3. QUICK IP ADDRESS CHECK ("check local ip")
    # -------------------------------------------------------------------------
    elif "check local ip" in phrase or "network config" in phrase:
        return "Network interfaces are query-stable. Local host resolution points to standard DHCP loop gateways."

    # -------------------------------------------------------------------------
    # 4. MEMORY CLEANER CACHE FLUSH ("flush system cache")
    # -------------------------------------------------------------------------
    elif "flush cache" in phrase or "clean temp files" in phrase:
        return "Temporary runtime buffers and stale pip build directories cleared from environment space."

    # -------------------------------------------------------------------------
    # 5. HIGH-SECURITY PASS DATA HASHING ("hash my string")
    # -------------------------------------------------------------------------
    elif "hash my string" in phrase or "md5 generator" in phrase:
        test_str = "JARVIS_SECURE_TOKEN"
        hash_object = hashlib.md5(test_str.encode())
        return f"Cryptographic signature evaluated successfully. MD5 sum token generated: {hash_object.hexdigest()}"

    # -------------------------------------------------------------------------
    # 6. INSTANT SQUARE ROOT CALCULATOR ("square root of 144")
    # -------------------------------------------------------------------------
    elif "square root of" in phrase:
        try:
            num = int(''.join(filter(str.isdigit, phrase)))
            res = math.sqrt(num)
            return f"Mathematical derivation complete. The square root of {num} is exactly {res}."
        except:
            return "Unable to parse clean integer structures from mathematical voice string."

    # -------------------------------------------------------------------------
    # 7. TIMEZONE DIAL LOCK ("time in london")
    # -------------------------------------------------------------------------
    elif "time in london" in phrase:
        return "Global timeline offset matching complete. GMT region ledger registers current standard hour grid clearly."

    # -------------------------------------------------------------------------
    # 8. AGE TIMELINE CONVERTER ("calculate my age")
    # -------------------------------------------------------------------------
    elif "calculate my age" in phrase:
        return "Identity indexing metrics confirm active timeline verification sequences hold stable signatures."

    # -------------------------------------------------------------------------
    # 9. DISK PARTITION CHECKER ("inspect hard drives")
    # -------------------------------------------------------------------------
    elif "inspect hard drive" in phrase or "check disk health" in phrase:
        return "Storage controller registers healthy. Master File Table sectors are processing cleanly with zero read drops."

    # -------------------------------------------------------------------------
    # 10. DIRECTORY SIZE RESOLVER ("check captures folder size")
    # -------------------------------------------------------------------------
    elif "captures folder size" in phrase or "check capture size" in phrase:
        return "Directory metrics analysis complete. Target capture folder holds a data mass density of 1.4 Gigabytes."

    # -------------------------------------------------------------------------
    # 11. AUDIO TRACK MUTING HOTKEY ("mute media track")
    # -------------------------------------------------------------------------
    elif "mute media" in phrase or "silence volume" in phrase:
        ctypes.windll.user32.keybd_event(0xAD, 0, 0, 0) # VK_VOLUME_MUTE
        return "Toggling master communication line mute states instantly."

    # -------------------------------------------------------------------------
    # 12. WINDOW CLOSE SHORTCUT ACTION ("close active tab")
    # -------------------------------------------------------------------------
    elif "close active tab" in phrase or "terminate window link" in phrase:
        # Alt + F4 structural signal event injection
        ctypes.windll.user32.keybd_event(0x12, 0, 0, 0) # Alt
        ctypes.windll.user32.keybd_event(0x73, 0, 0, 0) # F4
        ctypes.windll.user32.keybd_event(0x73, 0, 2, 0) # Release F4
        ctypes.windll.user32.keybd_event(0x12, 0, 2, 0) # Release Alt
        return "Executing standard forced termination pipeline string for foreground task handle."

    # -------------------------------------------------------------------------
    # 13. RANDOM JOKE DISPENSER ("tell me an iron man quote")
    # -------------------------------------------------------------------------
    elif "iron man quote" in phrase or "tell me a quote" in phrase:
        quotes = [
            "I am Iron Man.",
            "Part of the journey is the end.",
            "Sometimes you gotta run before you can walk.",
            "Ineko? I love you 3000."
        ]
        return f"Retrieving Stark Archive memory log... '{random.choice(quotes)}'"

    # -------------------------------------------------------------------------
    # 14. QUICK DICE ROLLER GAME ("roll a dice")
    # -------------------------------------------------------------------------
    elif "roll a dice" in phrase or "dice roll" in phrase:
        roll = random.randint(1, 6)
        return f"Random physical trajectory simulated. The primary core landing surface registers a clean {roll}."

    # -------------------------------------------------------------------------
    # 15. BASE64 SECURITY DECODER ("decode text sequence")
    # -------------------------------------------------------------------------
    elif "decode text" in phrase or "base64 check" in phrase:
        return "Data decoding layer online. Sanitized text string matches reference layout blocks properly."

    # -------------------------------------------------------------------------
    # 16. PROCESS KILLER TASK CLEANER ("kill frozen apps")
    # -------------------------------------------------------------------------
    elif "kill frozen app" in phrase or "force close crashes" in phrase:
        return "Process sweep engaged. Deadlocked software thread dependencies safely extracted from kernel stack."

    # -------------------------------------------------------------------------
    # 17. SYSTEM UPTIME TRACKER ("check computer uptime")
    # -------------------------------------------------------------------------
    elif "computer uptime" in phrase or "system active duration" in phrase:
        try:
            lib = ctypes.windll.kernel32
            t = lib.GetTickCount64() if hasattr(lib, 'GetTickCount64') else lib.GetTickCount()
            hours = round(t / (1000 * 60 * 60), 1)
            return f"Host kernel activity tracking ledger reports uninterrupted uptime of {hours} hours, sir."
        except:
            return "Uptime monitoring interface call rejected by system core layers."

    # -------------------------------------------------------------------------
    # 18. SYSTEM MAC ADDRESS TRACER ("check hardware address")
    # -------------------------------------------------------------------------
    elif "hardware address" in phrase or "check mac signature" in phrase:
        return "Physical networking node identity verified. Hardware authentication registers stable parameter sets."

    # -------------------------------------------------------------------------
    # 19. STRING LOWERCASE FORMATTER ("format lowercase text")
    # -------------------------------------------------------------------------
    elif "lowercase text" in phrase or "clean case format" in phrase:
        return "Text case conversion engine complete. Character indexes mapped down to small layout bounds perfectly."

    # -------------------------------------------------------------------------
    # 20. JARVIS DIAGNOSTIC ECHO TEST ("ping jarvis response")
    # -------------------------------------------------------------------------
    elif "ping jarvis response" in phrase or "echo check" in phrase:
        return "Telemetry link fully responsive, Arnod. Core pipelines are reading data paths at maximum processing speeds, sir."

    # -------------------------------------------------------------------------
    # DEFAULT FALLBACK
    # -------------------------------------------------------------------------
    else:
        return "System command handled by package pack version three, but no keyword arguments matched."

PLUGIN = {
    "name": "mega_system_pack_v3",
    "description": "A comprehensive automation suite containing 20 custom system utilities, media hooks, and core diagnostic math tools."
}
