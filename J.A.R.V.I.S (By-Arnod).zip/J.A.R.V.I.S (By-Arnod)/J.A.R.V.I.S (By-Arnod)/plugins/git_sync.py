import os
import subprocess
import json

def run(command_arguments="", **kwargs):
    absolute_file_path = str(command_arguments).strip()
    if not os.path.exists(absolute_file_path): 
        return "File path target link missing."
        
    remote, branch = "origin", "main"
    if os.path.exists("jarvis_config.json"):
        with open("jarvis_config.json", "r") as f:
            cfg = json.load(f).get("github_settings", {})
            remote, branch = cfg.get("remote_repository", remote), cfg.get("default_branch", branch)
    
    try:
        subprocess.run(f'git add "{absolute_file_path}"', check=True, shell=True)
        subprocess.run(f'git commit -m "JARVIS upload: {os.path.basename(absolute_file_path)}"', check=True, shell=True)
        subprocess.run(f'git push {remote} {branch}', check=True, shell=True)
        return "File synced to GitHub successfully."
    except Exception as e: 
        return f"Git process failed: {str(e)}"

PLUGIN = {
    "name": "git_automator",
    "description": "Stages, automatically formats native names, and pushes records to repositories."
}
