import ctypes
from ctypes import wintypes

class SYSTEM_POWER_STATUS(ctypes.Structure):
    _fields_ = [
        ('ACLineStatus', wintypes.BYTE),
        ('BatteryFlag', wintypes.BYTE),
        ('BatteryLifePercent', wintypes.BYTE),
        ('Reserved1', wintypes.BYTE),
        ('BatteryLifeTime', wintypes.DWORD),
        ('BatteryFullLifeTime', wintypes.DWORD),
    ]

def run(command_arguments="", **kwargs):
    status = SYSTEM_POWER_STATUS()
    # Pull status from local kernel32 core structures
    if ctypes.windll.kernel32.GetSystemPowerStatus(ctypes.byref(status)):
        percent = status.BatteryLifePercent
        charging = "plugged in and charging" if status.ACLineStatus == 1 else "running on battery cells"
        
        if percent == 255:
            return "Unable to resolve active power matrix telemetry records."
        return f"Core hardware power banks are currently at {percent} percent capacity, sir. The machine is {charging}."
    return "Failed to hook into local system power management frameworks."

PLUGIN = {
    "name": "battery_monitor",
    "description": "Reads local system kernel metrics to report real-time battery status and charging data."
}
