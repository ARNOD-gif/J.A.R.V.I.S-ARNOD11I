import sys
import ctypes

def run(command_arguments="", **kwargs):
    phrase = str(command_arguments).strip().lower()
    
    if "close" in phrase:
        sys.exit(0)
    elif "minimize" in phrase:
        ctypes.windll.user32.ShowWindow(ctypes.windll.user32.GetForegroundWindow(), 6)
        return "Minimizing active workspace interface."
    elif "maximize" in phrase:
        ctypes.windll.user32.ShowWindow(ctypes.windll.user32.GetForegroundWindow(), 3)
        return "Maximizing interface windows."
    return "Command layout variant not recognized."

PLUGIN = {
    "name": "window_controller",
    "description": "Modifies window sizes or safely terminates running engine runtime loops."
}
