import openpyxl
import json
import os

def run(command_arguments="", **kwargs):
    sheet_path = "calorie_counter.xlsx"
    if os.path.exists("jarvis_config.json"):
        with open("jarvis_config.json", "r") as f:
            sheet_path = json.load(f).get("file_paths", {}).get("calorie_sheet", sheet_path)

    if os.path.exists(sheet_path):
        try:
            workbook = openpyxl.load_workbook(sheet_path)
            active_sheet = workbook.active
            morning_food = active_sheet.cell(row=2, column=3).value
            morning_cals = active_sheet.cell(row=2, column=4).value
            return f"Hey! Doing great today—already tracked my {morning_food} at ({morning_cals} kcal)."
        except: 
            pass
    return "Hey! Caught your message. Finishing up some system tasks right now!"

PLUGIN = {
    "name": "chat_automation",
    "description": "Reads local macro tables to generate natural tracking conversation replies."
}
