import webbrowser
import json
import os

def run(command_arguments="", **kwargs):
    """
    Called by JARVIS whenever 'whatsapp call' command phrase triggers.
    """
    clean_input = str(command_arguments).strip().lower()
    target_number = ""

    if os.path.exists("jarvis_config.json"):
        with open("jarvis_config.json", "r") as f:
            contacts = json.load(f).get("whatsapp_contacts", {})
    else:
        contacts = {}

    if clean_input in contacts:
        target_number = contacts[clean_input]
    else:
        digits_only = "".join(filter(str.isdigit, clean_input))
        if digits_only: 
            target_number = digits_only

    if target_number:
        formatted_number = target_number.replace("+", "")
        webbrowser.open(f"https://whatsapp.com{formatted_number}")
        return f"Launching WhatsApp link for {command_arguments}."
    return f"Contact '{command_arguments}' not found."

PLUGIN = {
    "name": "whatsapp_name_caller",
    "description": "Places automated voice calls to saved contacts using WhatsApp Web links."
}
