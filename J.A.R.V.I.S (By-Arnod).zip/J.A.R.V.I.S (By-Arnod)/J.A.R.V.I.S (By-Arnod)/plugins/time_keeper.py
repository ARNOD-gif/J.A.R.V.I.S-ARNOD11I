import datetime

def run(command_arguments="", **kwargs):
    """
    Queries the master system clock parameters and translates them 
    into a clean, readable 12-hour format with AM/PM indicators.
    """
    try:
        # Extract current system clock metadata
        now = datetime.datetime.now()
        
        # %I forces a 12-hour number padding (01-12), %M tracks minutes, %p assigns AM/PM strings
        time_12hr = now.strftime("%I:%M %p")
        day_name = now.strftime("%A")
        
        return f"It is currently {time_12hr} on this fine {day_name}, sir."
        
    except Exception as err:
        return "Internal clock matrix synchronization loop dropped, sir. Unable to resolve temporal telemetry."

# Register the plugin configurations cleanly with the core engine validator
PLUGIN = {
    "name": "time_keeper",
    "description": "Queries host clock ticks to return a clean local time report in standard 12-hour formatting."
}
