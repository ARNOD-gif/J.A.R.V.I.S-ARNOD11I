import webbrowser
import urllib.request
import json

def run(command_arguments="", **kwargs):
    """
    Pings a secure, free IP-location API to dynamically find your city, 
    announces it, and opens Google Maps onto your interface screen.
    """
    try:
        # Increased request timeout window to 8 seconds to prevent fast drops
        with urllib.request.urlopen("http://ip-api.com", timeout=8) as response:
            data = json.loads(response.read().decode())
            
            city = data.get("city", "Unknown City")
            region = data.get("regionName", "Unknown Region")
            country = data.get("country", "India")
            lat = data.get("lat", "")
            lon = data.get("lon", "")
            
            if lat and lon:
                maps_url = f"https://www.google.com/maps/search/?api=1&query={lat},{lon}"
            else:
                maps_url = f"https://www.google.com/maps/search/?api=1&query={city}+{region}"
                
            webbrowser.open(maps_url)
            return f"You are currently in {city}, {region}, {country}, sir. I have launched the live interface map layout on your display screen."
            
    except Exception as err:
        # FIXED FALLBACK: Direct path routing to Google Maps landing space to prevent home routing
        webbrowser.open("https://www.google.com/maps/")
        return "I am initiating your geographic interface layer, sir, but your network timeout dropped. Displaying general map grid tracking."

PLUGIN = {
    "name": "location_finder",
    "description": "Locates your active network connection coordinates and pulls up a live map interface display."
}
