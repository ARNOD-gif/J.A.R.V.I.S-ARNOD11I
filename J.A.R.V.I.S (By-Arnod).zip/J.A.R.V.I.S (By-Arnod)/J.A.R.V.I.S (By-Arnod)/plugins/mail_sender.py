import smtplib
import json
import os
import re
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

def run(command_arguments="", recipient=None, subject=None, body=None, **kwargs):
    """
    Handles both direct conversational keywords passed by JARVIS's LLM core 
    AND raw typed string fallback processing.
    """
    # 1. Resolve Recipient Target
    target_name = recipient if recipient else ""
    mail_subject = subject if subject else ""
    mail_body = body if body else ""
    
    raw_text = str(command_arguments).strip()
    
    # Fallback Parsing if the LLM dumps everything into command_arguments text block
    if raw_text and not target_name:
        name_match = re.search(r'^(.*?)(?=\bsubject\b|$)', raw_text, re.IGNORECASE)
        subject_match = re.search(r'\bsubject\s+(.*?)(?=\bbody\b|$)', raw_text, re.IGNORECASE)
        body_match = re.search(r'\bbody\s+(.*)$', raw_text, re.IGNORECASE)

        target_name = name_match.group(1).strip().lower() if name_match else ""
        if subject_match: mail_subject = subject_match.group(1).strip()
        if body_match: mail_body = body_match.group(1).strip()

    # Clear trailing strings
    target_name = str(target_name).strip().lower()
    if not target_name:
        return "Recipient not specified, sir. Please provide the recipient name."

    # 2. Extract configuration from ledger file
    if not os.path.exists("jarvis_config.json"):
        return "Configuration file missing."

    with open("jarvis_config.json", "r") as f:
        email_ledger = json.load(f).get("email_ledger", {})

    if target_name in email_ledger:
        recipient_email = email_ledger[target_name]
    else:
        return f"No email contact mapped to '{target_name}' in config ledger."

    # Default fallbacks if parameters are blank strings
    if not mail_subject: mail_subject = "Automated JARVIS Update"
    if not mail_body: mail_body = "This is an automated transmission message from Mark LI framework."

    sender_email = "arnod082@gmail.com"
    sender_app_password = "vgex exax cjbu pdze"

    msg = MIMEMultipart()
    msg['From'] = sender_email
    msg['To'] = recipient_email
    msg['Subject'] = mail_subject
    msg.attach(MIMEText(mail_body, 'plain'))

    try:
        server = smtplib.SMTP("smtp.gmail.com", 587)
        server.starttls()
        server.login(sender_email, sender_app_password)
        server.sendmail(sender_email, recipient_email, msg.as_string())
        server.quit()
        return f"Email successfully sent to {target_name.upper()} ({recipient_email})."
    except Exception as err:
        return f"SMTP pipeline execution error: {str(err)}"

PLUGIN = {
    "name": "secure_mailer",
    "description": "Parses fields to send automated customized emails via Google secure servers."
}
